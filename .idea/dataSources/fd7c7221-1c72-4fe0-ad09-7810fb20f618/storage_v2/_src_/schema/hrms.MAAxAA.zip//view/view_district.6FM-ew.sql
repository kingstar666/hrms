CREATE VIEW view_district AS
  (SELECT
     `d1`.`district_code`                       AS `district_code`,
     `d1`.`district_name`                       AS `district_name`,
     `d1`.`short_name`                          AS `country`,
     `d4`.`city_code`                           AS `city_code`,
     `d4`.`city_name`                           AS `city_name`,
     `d4`.`province_code`                       AS `province_code`,
     `d4`.`province_name`                       AS `province_name`,
     `d4`.`province`                            AS `province`,
     concat(`d4`.`province`, `d1`.`short_name`) AS `short_name`
   FROM (`hrms`.`dic_districts` `d1` LEFT JOIN (SELECT
                                                  `d3`.`district_code` AS `city_code`,
                                                  `d3`.`district_name` AS `city_name`,
                                                  `d2`.`district_code` AS `province_code`,
                                                  `d2`.`district_name` AS `province_name`,
                                                  `d2`.`short_name`    AS `province`
                                                FROM (`hrms`.`dic_districts` `d3` LEFT JOIN `hrms`.`dic_districts` `d2`
                                                    ON ((`d3`.`super_distirct_code` = `d2`.`district_code`)))) `d4`
       ON ((`d1`.`super_distirct_code` = `d4`.`city_code`)))
   WHERE (`d1`.`district_level` = 3));

