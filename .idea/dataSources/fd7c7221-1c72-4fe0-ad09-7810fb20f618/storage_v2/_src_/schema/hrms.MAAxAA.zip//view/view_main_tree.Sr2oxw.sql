CREATE VIEW view_main_tree AS
  (SELECT
     `hrms`.`tab_org_info`.`org_id`       AS `id`,
     '0'                                  AS `pId`,
     `hrms`.`tab_org_info`.`org_name`     AS `NAME`,
     'orgId'                              AS `TYPE`,
     `hrms`.`tab_org_info`.`org_sequence` AS `sequence`
   FROM `hrms`.`tab_org_info`
   WHERE isnull(`hrms`.`tab_org_info`.`deleted`))
  UNION (SELECT
           `hrms`.`tab_dept_info`.`dept_id`       AS `id`,
           `hrms`.`tab_dept_info`.`org_id`        AS `pId`,
           `hrms`.`tab_dept_info`.`dept_name`     AS `NAME`,
           'deptId'                               AS `TYPE`,
           `hrms`.`tab_dept_info`.`dept_sequence` AS `sequence`
         FROM `hrms`.`tab_dept_info`
         WHERE isnull(`hrms`.`tab_dept_info`.`deleted`))
  UNION (SELECT
           `hrms`.`tab_person_info`.`person_id`       AS `id`,
           `hrms`.`tab_person_info`.`dept_id`         AS `pId`,
           `hrms`.`tab_person_info`.`person_name`     AS `NAME`,
           'personId'                                 AS `TYPE`,
           `hrms`.`tab_person_info`.`person_sequence` AS `sequence`
         FROM `hrms`.`tab_person_info`
         WHERE isnull(`hrms`.`tab_person_info`.`deleted`));

