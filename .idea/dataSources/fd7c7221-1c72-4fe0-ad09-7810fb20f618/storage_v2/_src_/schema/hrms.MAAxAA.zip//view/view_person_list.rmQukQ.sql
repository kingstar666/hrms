CREATE VIEW view_person_list AS
  (SELECT
     `hrms`.`tab_person_info`.`person_id`                          AS `person_id`,
     `hrms`.`tab_person_info`.`person_name`                        AS `person_name`,
     `hrms`.`tab_person_info`.`birthday`                           AS `birthday`,
     `hrms`.`tab_org_info`.`org_id`                                AS `org_id`,
     `hrms`.`tab_org_info`.`org_name`                              AS `org_name`,
     `hrms`.`tab_dept_info`.`dept_id`                              AS `dept_id`,
     `hrms`.`tab_dept_info`.`dept_name`                            AS `dept_name`,
     `hrms`.`dic_ethnicity`.`item_name`                            AS `ethnicity`,
     `hrms`.`dic_political_status`.`party_name`                    AS `party_name`,
     concat(`view_district`.`province`, `view_district`.`country`) AS `native_place`,
     `hrms`.`tab_person_info`.`modify_time`                        AS `modify_time`
   FROM ((((((`hrms`.`tab_person_info`
     LEFT JOIN `hrms`.`tab_org_info`
       ON ((`hrms`.`tab_person_info`.`org_id` = `hrms`.`tab_org_info`.`org_id`))) LEFT JOIN `hrms`.`tab_dept_info`
       ON ((`hrms`.`tab_person_info`.`dept_id` = `hrms`.`tab_dept_info`.`dept_id`))) LEFT JOIN `hrms`.`dic_ethnicity`
       ON ((`hrms`.`tab_person_info`.`ethnicity_id` = `hrms`.`dic_ethnicity`.`id`))) LEFT JOIN
     `hrms`.`tab_person_political_status`
       ON ((`hrms`.`tab_person_info`.`person_id` = `hrms`.`tab_person_political_status`.`personId`))) LEFT JOIN
     `hrms`.`dic_political_status` ON ((`hrms`.`tab_person_political_status`.`political_status_id` =
                                        `hrms`.`dic_political_status`.`party_id`))) LEFT JOIN `hrms`.`view_district`
       ON ((`hrms`.`tab_person_info`.`native_place_id` = `view_district`.`district_code`)))
   ORDER BY `hrms`.`tab_person_info`.`modify_time` DESC);

